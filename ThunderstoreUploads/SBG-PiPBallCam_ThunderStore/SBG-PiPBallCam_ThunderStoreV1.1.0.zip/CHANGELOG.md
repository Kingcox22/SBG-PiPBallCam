## 1.1.0
* Fixed Camera to always be behind the ball in the direction the ball is traveling instead of off to the side.
## 1.0.0
* Initial Release (In a rough state but mostly works)
